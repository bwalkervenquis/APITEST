using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace WebAPITest.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CompanyController : ControllerBase
    {        
        private IInsuranceClaimData _insuranceClaimData;
        private readonly ILogger<CompanyController> _logger;

        public CompanyController(ILogger<CompanyController> logger, IInsuranceClaimData insuranceClaimData)
        {
           _logger = logger;
           _insuranceClaimData = insuranceClaimData;
        }

        [HttpGet]
        public IEnumerable<Company> Get()
        {
            return _insuranceClaimData.Companies;        
        }

        [HttpGet("{companyId}")]
        public ActionResult<object> Get(int companyId)
        {
              var company =  _insuranceClaimData.Companies.FirstOrDefault(x => x.Id == companyId);     
              if(company == null)
              {
                  throw new Exception(String.Format("Company with Id {0} could not found",companyId));
              }

              return new { CompanyId = company.Id, 
                Name = company.Name,               
                Address1 = company.Address1,
                Address2 = company.Address2,        
                Address3 = company.Address3,                
                PostCode = company.PostCode,
                Country = company.Country,
                Active = company.Active,
                InsuranceEndDate = company.InsuranceEndDate,
                IsInsuranceActive = company.InsuranceEndDate >= DateTime.Now ? true : false
            };
        }

        [HttpGet("GetClaims/{companyId}")]
        public ActionResult<IEnumerable<object>> GetClaims(int companyId)
        {            
            var result = from company in _insuranceClaimData.Companies join 
                         claim in _insuranceClaimData.Claims on company.Id equals claim.CompanyId 
                         where company.Id == companyId 
                         select (company, claim); 
  
            var returnData = new List<object>();

                        foreach (var x in result)
                        {
                            returnData.Add(new {
                            CompanyId = x.company.Id, 
                            Name = x.company.Name,
                            InsuranceEndDate = x.company.InsuranceEndDate,
                            Ucr = x.claim.Ucr,      
                            ClaimDate  = x.claim.ClaimDate,
                            ClaimLossDate = x.claim.LossDate,
                            ClaimClosed = x.claim.Closed});                                
                        };

            return returnData;                            
        }
        
  [HttpGet("GetClaim/{claimUcr}")]
        public ActionResult<object> GetClaim(string claimUcr)
        {
            
            var result = from claim in _insuranceClaimData.Claims join 
                         company in _insuranceClaimData.Companies on claim.CompanyId equals company.Id 
                         where claim.Ucr == claimUcr 
                         select (company, claim); 
                        
            var returnData = new List<object>();

                        foreach (var x in result)
                        {
                            returnData.Add(new {                            
                            Ucr = x.claim.Ucr,
                            CompanyName = x.company.Name,                                                        
                            ClaimInDays  = (DateTime.Now - x.claim.ClaimDate).TotalDays
                            });                                
                        };
                        
            return returnData.Count > 0 ? returnData.FirstOrDefault() : new object();                        
        }

    [HttpPut]
    public void UpdateClaim(Claims claim)
    {
        if(String.IsNullOrEmpty(claim.Ucr))
        {
            throw new Exception("UCR does not exists in Input Data");
        }

        if(!_insuranceClaimData.Claims.Any(x => x.Ucr == claim.Ucr))
        {
            throw new Exception("Data doesn't exists for Claim");
        }        
        _insuranceClaimData.UpdateClaim(claim);                                             
    }

    }
}