using System;

namespace WebAPITest
{
    public class Claims
    {
        public string Ucr { get; set; }

        public int CompanyId { get; set; }

        public DateTime ClaimDate { get; set; }

        public DateTime LossDate { get; set; }

        public bool Closed{get;set;}
                        
    }
}
