using System;
using System.Collections.Generic;
using System.Linq;

namespace WebAPITest
{

    public interface IInsuranceClaimData 
    {
        void AddCompany(Company company);
        void AddClaim(Claims claim);   
        void UpdateClaim(Claims claim);
        List<Claims> Claims { get;}
        List<Company> Companies { get;}
    }

    public class InsuranceClaimData : IInsuranceClaimData
    {

        private List<Company> _companies;
        private List<Claims> _claims;

        public InsuranceClaimData(){                        
            
            _claims = new List<Claims>();
            _claims.Add(new Claims{ Ucr="UCR-1", CompanyId = 1, Closed = false, ClaimDate = new DateTime(2023,01,21) });
            _claims.Add(new Claims{ Ucr="UCR-2", CompanyId = 1, Closed = false, ClaimDate = new DateTime(2023,01,21)});
            _claims.Add(new Claims{ Ucr="UCR-3", CompanyId = 1, Closed = false, ClaimDate = new DateTime(2023,01,21)});
            _claims.Add(new Claims{ Ucr="UCR-4", CompanyId = 2, Closed = false, ClaimDate = new DateTime(2021,01,21)});
            _claims.Add(new Claims{ Ucr="UCR-5", CompanyId = 3, Closed = true, ClaimDate = new DateTime(2022,01,21)});

            _companies = new List<Company>();
            _companies.Add(new Company{ Id = 1, Name ="Company 1", Active = true, InsuranceEndDate =new DateTime(2024,01,21) });            
            _companies.Add(new Company{ Id = 2, Name ="Company 2", Active = true,InsuranceEndDate =new DateTime(2022,01,21) });
            _companies.Add(new Company{ Id = 3, Name ="Company 3", Active = true, InsuranceEndDate =new DateTime(2024,01,29) });
        }

        public void AddCompany(Company company)
        {
            var _lock = new Object();
            int nextId = 0;
            lock(_lock)
            {
                nextId = _companies.Max(x => x.Id) + 1;
            }

            company.Id = nextId;
            _companies.Add(company);
        }

        public void AddClaim(Claims claim)
        {            
            _claims.Add(claim);
        }

        public void UpdateClaim(Claims claim)
        {
            var index = _claims.FindIndex(x => x.Ucr == claim.Ucr);
            _claims.RemoveAt(index);
            _claims.Add(claim);            
        }

        public List<Claims> Claims { get {return _claims;}}
        public List<Company> Companies { get {return _companies;}}

    }
}
